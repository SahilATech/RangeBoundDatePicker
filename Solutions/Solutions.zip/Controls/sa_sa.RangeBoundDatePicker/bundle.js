/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./RangeBoundDatePicker/HelloWorld.tsx":
/*!*********************************************!*\
  !*** ./RangeBoundDatePicker/HelloWorld.tsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   HelloWorld: () => (/* binding */ HelloWorld)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass HelloWorld extends react__WEBPACK_IMPORTED_MODULE_0__.Component {\n  constructor(props) {\n    super(props);\n    this.calendarDayProps = {\n      customDayCellRef: (element, date, classNames) => {\n        if (element) {\n          element.title = 'custom title from customDayCellRef: ' + date.toString();\n          if (this.props.disableDays.includes(date.getDay()) || this.state.normalizedRestrictedDates.includes(this.normalizeDate(date))) {\n            classNames.dayOutsideBounds && element.classList.add(classNames.dayOutsideBounds);\n            element.children[0].disabled = true;\n          }\n        }\n      }\n    };\n    this.DateRange = (minDate, maxDate) => {\n      this.setState({\n        minDate,\n        maxDate\n      });\n    };\n    this.restrictedDates = dates => {\n      var dts = dates.map(date => this.normalizeDate(date));\n      this.setState({\n        normalizedRestrictedDates: dts\n      });\n    };\n    this.resetDatePicker = () => {\n      this.setState({\n        currentSelectedDate: this.state.initialSelectedDate\n      });\n      this.props.onSelectDate(this.state.initialSelectedDate);\n    };\n    this.state = {\n      minDate: props.minDate,\n      maxDate: props.maxDate,\n      initialSelectedDate: props.selectedDate,\n      currentSelectedDate: props.selectedDate,\n      normalizedRestrictedDates: this.props.restrictedDates.map(date => this.normalizeDate(date))\n    };\n    // Attach methods and state to the global window object\n    // eslint-disable-next-line @typescript-eslint/no-explicit-any\n    window[\"pcfDateControl_\".concat(props.uniqueKey)] = {\n      dateRange: this.DateRange,\n      restrictedDates: this.restrictedDates\n    };\n    this.updateSelectedDate = this.updateSelectedDate.bind(this);\n  }\n  normalizeDate(date) {\n    return \"\".concat(date.getFullYear(), \"-\").concat(date.getMonth(), \"-\").concat(date.getDate());\n  }\n  getDatePickerStrings() {\n    return Object.assign(Object.assign({}, _fluentui_react__WEBPACK_IMPORTED_MODULE_1__.defaultDatePickerStrings), {\n      isOutOfBoundsErrorMessage: \"Date must be between \".concat(this.state.minDate.toLocaleDateString(), \" and \").concat(this.state.maxDate.toLocaleDateString())\n    });\n  }\n  updateSelectedDate(newValue) {\n    this.props.onSelectDate(newValue);\n    this.setState({\n      currentSelectedDate: newValue !== null && newValue !== void 0 ? newValue : null\n    });\n  }\n  render() {\n    var _a;\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: styles.container\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.DatePicker, {\n      className: styles.datePicker,\n      placeholder: \"Select a date...\",\n      ariaLabel: \"Select a date\",\n      strings: this.getDatePickerStrings(),\n      minDate: this.state.minDate,\n      maxDate: this.state.maxDate,\n      onSelectDate: this.updateSelectedDate,\n      // eslint-disable-next-line react/jsx-no-duplicate-props\n      value: (_a = this.state.currentSelectedDate) !== null && _a !== void 0 ? _a : undefined,\n      showGoToToday: true,\n      highlightSelectedMonth: true,\n      allowTextInput: this.props.allowTextInput,\n      showMonthPickerAsOverlay: this.props.showMonthPickerAsOverlay,\n      showWeekNumbers: this.props.showWeekNumbers,\n      isRequired: this.props.isRequired,\n      disabled: this.props.isDisable,\n      calendarAs: props => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Calendar, Object.assign({}, props, {\n        calendarDayProps: this.calendarDayProps\n      }))\n    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.DefaultButton, {\n      disabled: this.props.isDisable,\n      id: \"DefaultButton\",\n      onClick: this.resetDatePicker,\n      text: \"Revert\"\n    })));\n  }\n}\nvar styles = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.mergeStyleSets)({\n  container: {\n    display: 'flex',\n    alignItems: 'baseline',\n    gap: '10px',\n    minWidth: '-webkit-fill-available'\n  },\n  datePicker: {\n    flexGrow: 1 // Allows DatePicker to take available space\n  }\n});\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./RangeBoundDatePicker/HelloWorld.tsx?");

/***/ }),

/***/ "./RangeBoundDatePicker/index.ts":
/*!***************************************!*\
  !*** ./RangeBoundDatePicker/index.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   RangeBoundDatePicker: () => (/* binding */ RangeBoundDatePicker)\n/* harmony export */ });\n/* harmony import */ var _HelloWorld__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HelloWorld */ \"./RangeBoundDatePicker/HelloWorld.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass RangeBoundDatePicker {\n  constructor() {\n    this._minDate = new Date();\n    this._maxDate = new Date();\n    this._newSelectedDate = null;\n    this._disableDays = [];\n    this._restrictedDates = [];\n    this.onDateSelectChange = newValue => {\n      this._newSelectedDate = newValue !== null && newValue !== void 0 ? newValue : null;\n      this.notifyOutputChanged();\n    };\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  init(context, notifyOutputChanged, state) {\n    var _a, _b;\n    this.notifyOutputChanged = notifyOutputChanged;\n    this._selectedDate = context.parameters.DateAndTime.raw;\n    this._uniqueKey = (_b = (_a = context.parameters.DateAndTime.attributes) === null || _a === void 0 ? void 0 : _a.LogicalName) !== null && _b !== void 0 ? _b : \"\";\n    this._allowTextInput = context.parameters.allowTextInput.raw;\n    this._showMonthPickerAsOverlay = context.parameters.showMonthPickerAsOverlay.raw;\n    this._showWeekNumbers = context.parameters.showWeekNumbers.raw;\n    this._isRequired = context.parameters.isRequired.raw;\n    //Specific Duration\n    if (context.parameters.dateRangeSelector.raw == '0') {\n      this._minDate = this.dateConverter(context.parameters.minDate.raw);\n      this._maxDate = this.dateConverter(context.parameters.maxDate.raw);\n    }\n    //Flexible Time Frame\n    else if (context.parameters.dateRangeSelector.raw == '1') {\n      this._minDate = this.dateConverter(context.parameters.pastTimeFrame.raw, \"past\");\n      this._maxDate = this.dateConverter(context.parameters.futureTimeFrame.raw, \"future\");\n    }\n    if (context.parameters.disableDays.raw == '6') this._disableDays = [6]; //saturdays\n    else if (context.parameters.disableDays.raw == '0') this._disableDays = [0]; //Sundays\n    else if (context.parameters.disableDays.raw == '7') this._disableDays = [0, 6]; //saturdays & Sundays\n    else this._disableDays = [];\n    this._restrictedDates = this.disabledDatesParse(context.parameters.disabledDates.raw);\n    this._isDisable = context.mode.isControlDisabled;\n  }\n  disabledDatesParse(listDates) {\n    try {\n      if (!listDates) return [];\n      var dates = listDates.split(',').map(dateStr => dateStr.trim()).filter(dateStr => dateStr.length == 10).map(dateStr => new Date(dateStr)).filter(date => !isNaN(date.getTime()));\n      return dates;\n    } catch (error) {\n      return [];\n    }\n  }\n  dateConverter(date) {\n    var duration = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : \"\";\n    try {\n      // normal date\n      if (duration == \"\") return new Date(date);\n      //durations\n      else if (duration !== \"\") {\n        // Split the duration string by '.' and convert to numbers\n        var [yearsStr, monthsStr, daysStr] = date.split('.').map(part => part.trim());\n        // Convert strings to numbers and provide default values for missing parts\n        var years = this.isValidNumber(yearsStr) ? Number(yearsStr) : 0;\n        var months = this.isValidNumber(monthsStr) ? Number(monthsStr) : 0;\n        var days = this.isValidNumber(daysStr) ? Number(daysStr) : 0;\n        var todays = new Date();\n        if (duration == \"future\") {\n          todays.setFullYear(todays.getFullYear() + years);\n          todays.setMonth(todays.getMonth() + months);\n          todays.setDate(todays.getDate() + days);\n        } else if (duration == \"past\") {\n          todays.setFullYear(todays.getFullYear() - years);\n          todays.setMonth(todays.getMonth() - months);\n          todays.setDate(todays.getDate() - days);\n        }\n        return todays;\n      } else return new Date();\n    } catch (error) {\n      console.log(error);\n      return new Date();\n    }\n  }\n  isValidNumber(value) {\n    var num = Number(value);\n    return !isNaN(num) && isFinite(num);\n  }\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  updateView(context) {\n    var props = {\n      minDate: this._minDate,\n      maxDate: this._maxDate,\n      selectedDate: this._selectedDate,\n      onSelectDate: this.onDateSelectChange,\n      uniqueKey: this._uniqueKey,\n      allowTextInput: this._allowTextInput,\n      showMonthPickerAsOverlay: this._showMonthPickerAsOverlay,\n      showWeekNumbers: this._showWeekNumbers,\n      isRequired: this._isRequired,\n      disableDays: this._disableDays,\n      restrictedDates: this._restrictedDates,\n      isDisable: this._isDisable\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_HelloWorld__WEBPACK_IMPORTED_MODULE_0__.HelloWorld, props);\n  }\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\r\n   */\n  getOutputs() {\n    var _a;\n    return {\n      DateAndTime: (_a = this._newSelectedDate) !== null && _a !== void 0 ? _a : undefined\n    };\n  }\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./RangeBoundDatePicker/index.ts?");

/***/ }),

/***/ "@fluentui/react":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./RangeBoundDatePicker/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('sa.RangeBoundDatePicker', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.RangeBoundDatePicker);
} else {
	var sa = sa || {};
	sa.RangeBoundDatePicker = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.RangeBoundDatePicker;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}